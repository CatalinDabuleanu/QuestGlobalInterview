﻿using System;

namespace QuestGlobalProblemTwo
{
    public class Program
    {
        static void Main(string[] args)
        {
            var inputString = Console.ReadLine();
            var appearances = 0;
            var charToCheck = inputString[0];
            var outputString = string.Empty;
            foreach(var character in inputString)
            {
                if(character == charToCheck)
                {
                    appearances++;
                }
                else
                {
                    outputString += inputString[(inputString.IndexOf(character) - 1)].ToString() + appearances.ToString();
                    appearances = 1;
                    charToCheck = character;
                }
            }
            outputString += inputString[inputString.Length - 1].ToString() + appearances;

            Console.WriteLine(outputString);
        }
    }
}
