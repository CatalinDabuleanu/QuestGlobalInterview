﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace QuestGlobalProblemOne
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.Write("n = ");
            var nString = Console.ReadLine();
            int n;
            var parsedSuccessfully = Int32.TryParse(nString, out n);
            var listOfNumbers = new List<int>();
            if (parsedSuccessfully)
            {
                if (n >= 4)
                {
                    for(int i = 0; i < n; i++)
                    {
                        Console.Write("Element {0} = ", i + 1);
                        var elementString = Console.ReadLine();
                        int elementInt;
                        var intParsedCorrectly = Int32.TryParse(elementString, out elementInt);
                        if (intParsedCorrectly)
                        {
                            listOfNumbers.Add(elementInt);
                        }
                        else
                        {
                            Console.WriteLine("Element should be a valid integer");
                            return;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("n should be greater or equal with 4");
                }
            }
            else
            {
                Console.WriteLine("n should be a valid integer");
            }

            //no need to check if first two numbers exist since the problem states clearly that the sequence contains at least 4 numbers
            var dif = listOfNumbers[1] - listOfNumbers[0];

            var isArithmeticProgression = true;

            foreach(var number in listOfNumbers)
            {
                if (number != listOfNumbers.Last())
                {
                    var nextNumber = listOfNumbers[listOfNumbers.IndexOf(number) + 1];
                    if (nextNumber - number != dif)
                    {
                        isArithmeticProgression = false;
                    }
                }
            }
            if (isArithmeticProgression)
            {
                Console.WriteLine("YES");
            }
            else
            {
                Console.WriteLine("NO");
            }
        }
    }
}
